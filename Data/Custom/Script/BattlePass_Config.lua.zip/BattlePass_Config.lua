local Config = {}

-- [[ CONFIGURA��ES GERAIS ]]
Config.DebugMode = true
Config.ExpirationDate = {year = 2026, month = 12, day = 31, hour = 23, min = 59}
Config.PriceWCoinC = 50 -- Pre�o do Passe Premium em WCoins

-- Tipos de Miss�o
Config.Types = {
    MONSTER_KILL = 1, PLAYER_KILL = 2, RESET = 3, MASTER_RESET = 4, EVENT = 5
}

-- Fun��o Auxiliar para Cria��o de Itens
local function Item(sec, idx, lv, sk, lk, opt, exc, anc, sct, s_tbl, dur)
    return {
        Section = sec, Index = idx, Level = lv, Skill = sk, Luck = lk, 
        Option = opt, Exc = exc, Anc = anc, SocketCount = sct, 
        Sockets = s_tbl or {255, 255, 255, 255, 255}, Duration = dur
    }
end

-- [[ RECOMPENSAS POR N�VEL ]]
Config.Rewards = {
    [1] = { 
        Free = { 
            { Type = "ITEM", Data = Item(14, 13, 0, 0, 0, 0, 0, 0, 0, nil, 0), Count = 1 }
        }, 
        Premium = { 
            { Type = "ITEM", Data = Item(0, 19, 13, 1, 1, 7, 63, 0, 5, {1,1,1,1,1}, 86400), Count = 1 } 
        } 
    },
    [2] = { 
        Free = { 
            { Type = "ITEM", Data = Item(14, 13, 0, 0, 0, 0, 0, 0, 0, nil, 0), Count = 1 }
        }, 
        Premium = { 
            { Type = "ITEM", Data = Item(0, 55, 13, 1, 1, 7, 63, 0, 0, nil, 0), Count = 1 } 
        } 
    },
    [3] = { 
        Free = { 
            { Type = "WCOIN", Value = 100 }
        },
        Premium = { 
            { Type = "ITEM", Data = Item(0, 55, 13, 1, 1, 7, 63, 0, 0, nil, 0), Count = 1 }, 
            { Type = "WCOIN", Value = 50 } 
        }
    }
}

-- [[ MISS�ES DI�RIAS (1 a 31) ]]
Config.DailyMissions = {
    [17] = { -- Agrupamento de todas as miss�es para o Dia 12
        { ID = 1001, Name = "Matar 6 Budge Dragon", Type = 1, TargetID = 2, Count = 6, Stars = 50, ReqPremium = false },
        { ID = 1002, Name = "Efetuar 1 Reset", Type = 3, TargetID = -1, Count = 1, Stars = 30, ReqPremium = false },
        { ID = 1003, Name = "Matar 5 Elite Bull Fighter", Type = 1, TargetID = 1, Count = 5, Stars = 20, ReqPremium = true },
    },
}

-- [[ MISS�ES SEMANAIS (1 a 4) ]]
Config.WeeklyMissions = {
    [3] = {
        { ID = 2001, Name = "Matar 5 Blood Wolf", Type = 1, TargetID = 50, Count = 5, Stars = 50, ReqPremium = false },
        { ID = 2002, Name = "PVP vs SM", Type = 2, TargetID = 0, Count = 5, Stars = 30, ReqPremium = true },
        { ID = 2003, Name = "Efetuar 3 Resets", Type = 3, TargetID = -1, Count = 3, Stars = 60, ReqPremium = false },
        { ID = 2004, Name = "PVP vs SM", Type = 2, TargetID = 0, Count = 5, Stars = 30, ReqPremium = true },
    },
}

return Config