ProtocolFunctions = {}

BridgeFunctionAttach('ClientProtocol','ClientProtocolRecv')

local ClientProtocol_Handles = {}
function ClientProtocolRecv(Packet, PacketName)
	for i = 1, #ClientProtocol_Handles do
		if ClientProtocol_Handles[i].callback(Packet, PacketName)
		then
			return
		end
	end

end

function ProtocolFunctions.ClientProtocol(callback)
	table.insert(ClientProtocol_Handles, { callback = callback })
end

function ProtocolFunctions.Init()
	ProtocolFunctions.ClientProtocol(ProtocolFunctions.ProtocolRecv)
end


function ProtocolFunctions.ProtocolRecv(Packet, PacketName)
	Console(3,string.format("[ProtocolCore] Name: %s Head: %d",PacketName,Packet))
end

ProtocolFunctions.Init()