--############################################################################
-- You need to set all scripts requires here
-- ===========================================================================


require('System\\ScriptCore')

require('System\\ProtocolCore')
require('System\\LoadImages')
require('Util\\Defines')
require('Util\\KeysValue')
require('Util\\Json')


requirefolder('PZDEV\\InvasionLore')
requirefolder('PZDEV\\CreationCoupon')
requirefolder('Scripts\\WindowTitle')