
return {
    TotalPages = 6,

    MainInterface = {
        ResolutionSettingsY = {
            [1] = 20,
            [2] = 40,
            [3] = 50,
            [4] = 25,
            [5] = 45,
            [6] = 35,
            [7] = 60,
            [8] = 50,
        }
    },

    InvasionButton = {
        ResolutionSettings = {
            [1] = { OffsetX = -100, Y = 100,  Width = 60, Height = 60 },
            [2] = { OffsetX = -200, Y = 0,  Width = 75, Height = 75 },
            [3] = { OffsetX = -275, Y = 0,  Width = 75, Height = 75 },
            [4] = { OffsetX = -220, Y = 0,  Width = 75, Height = 75 },
            [5] = { OffsetX = -240, Y = 0,  Width = 75, Height = 75 },
            [6] = { OffsetX = -290, Y = 0,  Width = 75, Height = 75 },
            [7] = { OffsetX = -330, Y = 0,  Width = 75, Height = 75 },
            [8] = { OffsetX = -415, Y = 0,  Width = 75, Height = 75 }
        },
    },

    Info = {
        [1] = { 
            Title = "T1: O Retorno do White Wizard", 
            Nome = "Nome: White Wizard", 
            Tipo = "Tipo: Boss", 
            Mapa = "Origem: Lorencia", 
            Forca = "Força: 20.000 | 35.000", 
            Defesa = "Defesa: 1500", 
            Vida = "Vida: 2.000.000", 
            MonsterIndex = 135, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
            MonsterRender = {
                [1] = { OffsetX = 82, Y = 255, Scale = 0.70 },
                [2] = { OffsetX = 82, Y = 255, Scale = 0.85 },
                [3] = { OffsetX = 82, Y = 255, Scale = 1.00 },
                [4] = { OffsetX = 82, Y = 255, Scale = 0.70 },
                [5] = { OffsetX = 82, Y = 255, Scale = 0.85 },
                [6] = { OffsetX = 82, Y = 255, Scale = 0.85 },
                [7] = { OffsetX = 82, Y = 255, Scale = 0.95 },
                [8] = { OffsetX = 82, Y = 255, Scale = 0.95 }
            },
        },
        [2] = { 
            Title = "T1: O Trono de Gelo em Devias", 
            Nome = "Nome: Ice Queen", 
            Tipo = "Tipo: Boss", 
            Mapa = "Origem: Devias", 
            Forca = "Força: 25.000 | 40.000", 
            Defesa = "Defesa: 2.000", 
            Vida = "Vida: 4.000.000", 
            MonsterIndex = 25, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
            MonsterRender = {
                [1] = { OffsetX = 80, Y = 245, Scale = 1.10 },
                [2] = { OffsetX = 80, Y = 245, Scale = 1.40 },
                [3] = { OffsetX = 80, Y = 245, Scale = 1.95 },
                [4] = { OffsetX = 80, Y = 245, Scale = 1.05 },
                [5] = { OffsetX = 80, Y = 245, Scale = 1.45 },
                [6] = { OffsetX = 80, Y = 245, Scale = 1.45 },
                [7] = { OffsetX = 80, Y = 245, Scale = 1.45 },
                [8] = { OffsetX = 80, Y = 245, Scale = 1.45 }
            },
        },
        [3] = { 
            Title = "T1: O Despertar da Fúria da Natureza", 
            Nome = "Nome: Ice Napin", 
            Tipo = "Tipo: Boss", 
            Mapa = "Origem: Noria", 
            Forca = "Força: 30.000 | 45.000", 
            Defesa = "Defesa: 2.500", 
            Vida = "Vida: 6.000.000", 
            MonsterIndex = 558, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
             MonsterRender = {
                [1] = { OffsetX = 80, Y = 255, Scale = 1.15 },
                [2] = { OffsetX = 80, Y = 255, Scale = 1.45 },
                [3] = { OffsetX = 80, Y = 255, Scale = 1.95 },
                [4] = { OffsetX = 80, Y = 255, Scale = 1.25 },
                [5] = { OffsetX = 80, Y = 255, Scale = 1.35 },
                [6] = { OffsetX = 80, Y = 255, Scale = 1.35 },
                [7] = { OffsetX = 80, Y = 255, Scale = 1.45 },
                [8] = { OffsetX = 80, Y = 255, Scale = 1.65 }
            },
        },
        [4] = { 
            Title = "T1: O Rugido das Profundezas", 
            Nome = "Nome: Hydra", 
            Tipo = "Tipo: Boss", 
            Mapa = "Origem: Atlans", 
            Forca = "Força: 100.000 | 150.000", 
            Defesa = "Defesa: 3.500", 
            Vida = "Vida: 10.000.000", 
            MonsterIndex = 49, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
           MonsterRender = {
                [1] = { OffsetX = 85, Y = 245, Scale = 1.50 },
                [2] = { OffsetX = 85, Y = 245, Scale = 1.90 },
                [3] = { OffsetX = 85, Y = 245, Scale = 2.60 },
                [4] = { OffsetX = 85, Y = 245, Scale = 1.60 },
                [5] = { OffsetX = 85, Y = 235, Scale = 1.90 },
                [6] = { OffsetX = 85, Y = 235, Scale = 1.90 },
                [7] = { OffsetX = 85, Y = 235, Scale = 2.20 },
                [8] = { OffsetX = 85, Y = 235, Scale = 2.20 }
            },
        },	
        [5] = { 
            Title = "T1: As Chamas da Destruição", 
            Nome = "Nome: Hell Maine", 
            Tipo = "Tipo: Chefe Supremo", 
            Mapa = "Origem: Aida", 
            Forca = "Força: 200.000 | 280.000", 
            Defesa = "Defesa: 4.000", 
            Vida = "Vida: 12.000.000", 
            MonsterIndex = 511, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
             MonsterRender = {
                [1] = { OffsetX = 82, Y = 255, Scale = 0.75 },
                [2] = { OffsetX = 82, Y = 255, Scale = 1.05 },
                [3] = { OffsetX = 82, Y = 255, Scale = 1.40 },
                [4] = { OffsetX = 82, Y = 255, Scale = 0.80 },
                [5] = { OffsetX = 82, Y = 245, Scale = 1.10 },
                [6] = { OffsetX = 82, Y = 245, Scale = 1.10 },
                [7] = { OffsetX = 82, Y = 245, Scale = 1.30 },
                [8] = { OffsetX = 82, Y = 245, Scale = 1.30 }
            },
        },			
		[6] = { 
            Title = "T1: O Colosso do Deserto Esquecido", 
            Nome = "Nome: Narcondra", 
            Tipo = "Tipo: Boss", 
            Mapa = "Origem: Karutan 1/2",
            Forca = "Força: 250.000 | 300.000", 
            Defesa = "Defesa: 4.500", 
            Vida = "Vida: 15.000.000",
            MonsterIndex = 576, -- Índice do monstro para renderização
            UltimoAssassino = nil,
            -- Configurações de renderização do monstro
            MonsterRender = {
                [1] = { OffsetX = 82, Y = 270, Scale = 0.75 },
                [2] = { OffsetX = 82, Y = 270, Scale = 0.95 },
                [3] = { OffsetX = 82, Y = 270, Scale = 1.35 },
                [4] = { OffsetX = 82, Y = 270, Scale = 0.85 },
                [5] = { OffsetX = 82, Y = 265, Scale = 1.10 },
                [6] = { OffsetX = 82, Y = 265, Scale = 1.10 },
                [7] = { OffsetX = 82, Y = 265, Scale = 1.30 },
                [8] = { OffsetX = 82, Y = 265, Scale = 1.30 }
            },
        },
    },
    
    -- História/Lore por página
    Lore = {
		[1] = {
			L1 = "Das planícies de Lorencia surge o White Wizard,",
			L2 = "um feiticeiro ancestral corrompido pelas trevas.",
			L3 = " ",
			L4 = "Ao tomar o Fragmento Shadow como seu poder,",
			L5 = "torceu sua magia em pura maldição e dor.",
			L6 = "Seus feitiços ecoam pelas terras do continente,",
			L7 = "trazendo terror e consumindo a esperança.",
			L8 = " ",
			L9 = "Ele é o arauto da corrupção que se aproxima,",
			L10 = "aquele que abriu o caminho da perdição.",
			L11 = "Seu domínio anuncia a queda da primeira luz,",
			L12 = "e o início da trilha dos fragmentos sombrios.",
			L13 = " ",
        },
        [2] = {
            L1 = "Das florestas de Noria surgiu o Ice Napin,",
			L2 = "um espírito da natureza deformado pelo poder.",
			L3 = " ",
			L4 = "O Fragmento Nature corrompeu raízes sagradas,",
			L5 = "virando vida em decadência e força em ruína.",
			L6 = "Agora suas árvores choram gelo e dor incessante,",
			L7 = "e sua presença congela até a seiva do mundo.",
			L8 = " ",
			L9 = "Ele guarda o elo da vida, agora distorcida,",
			L10 = "e une a sombra ao ciclo perdido da floresta.",
			L11 = "Derrotá-lo é purificar parte da essência caída,",
			L12 = "mas também despertar ventos de fúria gelada.",
			L13 = " ",          
        
        },
        [3] = {
            L1 = "Nas montanhas gélidas reina a cruel Ice Queen,",
			L2 = "soberana que manipula o Fragmento Frost.",
			L3 = " ",
			L4 = "Seu poder congela batalhões em poucos segundos,",
			L5 = "e sua beleza esconde a máscara da tirania.",
			L6 = "Devias tornou-se prisão de gelo e desespero,",
			L7 = "onde nem a luz ousa atravessar a neblina fria.",
			L8 = " ",
			L9 = "Ela conecta a vida perdida ao frio sem fim,",
			L10 = "sendo o elo da estagnação na corrupção.",
			L11 = "Seu fim abrirá caminho para as águas profundas,",
			L12 = "onde o abismo aguarda faminto por novas almas.",
			L13 = " ",	
        },
        [4] = {
			L1 = "Sob as águas agitadas de Atlans desperta a Hydra,",
			L2 = "uma besta ancestral marcada pelo Fragmento Abyss.",
			L3 = " ",
			L4 = "Cada cabeça ruge com caos e fúria incontida,",
			L5 = "afogando mares e corações dos aventureiros.",
			L6 = "O Fragmento Abyss abre o véu da perdição,",
			L7 = "ligando o gelo eterno ao caos das profundezas.",
			L8 = " ",
			L9 = "Sua queda revelará as chamas do inferno próximo,",
			L10 = "onde o fogo há de devorar o que restar da terra.",
			L11 = "Mas até lá, seu rugido mantém o ciclo sombrio,",
			L12 = "e anuncia a guerra que logo se aproxima.",
			L13 = " ",	
        },
        [5] = {
			L1 = "Entre as florestas ardentes ergue-se Hell Maine,",
			L2 = "besta flamejante possuída pelo Fragmento Infernal.",
			L3 = " ",
			L4 = "Seu rugido incendeia céus e corrói esperanças,",
			L5 = "transformando verdes terras em cinzas eternas.",
			L6 = "O fogo é a ponte entre o caos e a ruína final,",
			L7 = "e seu ardor prepara o caminho para o deserto.",
			L8 = " ",
			L9 = "Ele guarda o elo do fogo eterno da destruição,",
			L10 = "conectando o abismo às areias esquecidas.",
			L11 = "Somente derrotando suas chamas será possível",
			L12 = "enfrentar o colosso que desperta em Karutan.",
			L13 = " ",
    },
        [6] = {
			L1 = "No deserto esquecido desperta Narcondra,",
			L2 = "titã moldado pela areia e pelo Fragmento Earth.",
			L3 = " ",
			L4 = "Sua fúria faz tremer o solo de todo continente,",
			L5 = "e sua marcha sela o destino das últimas cidades.",
			L6 = "Ele é o guardião final da corrupção ancestral,",
			L7 = "onde todos os fragmentos convergem em ruína.",
			L8 = " ",
			L9 = "A batalha contra Narcondra decidirá o fim,",
			L10 = "ou a restauração do equilíbrio dos fragmentos.",
			L11 = "Se derrotado, a esperança poderá renascer,",
			L12 = "se não, a terra será consumida na escuridão.",
			L13 = " ",
        }	
    },
    
    Ranking = {}
}