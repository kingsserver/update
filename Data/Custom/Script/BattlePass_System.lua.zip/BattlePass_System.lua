local CONFIG = require("Scripts\\BattlePass\\BattlePass_Config")

BattlePass = {}

-- [[ AUXILIARES T�CNICOS ]]
local function BP_Log(color, message)
    if CONFIG.DebugMode then LogColor(color, string.format("[BattlePass] %s", message)) end
end

function BattlePass.IsExpired()
    return os.time() > os.time(CONFIG.ExpirationDate)
end

function BattlePass.GetCurrentTime()
    local date = os.date("*t")
    return { Day = date.day, Week = math.ceil(date.day / 7) }
end

function BattlePass.HasPass(aIndex)
    local account = GetObjectAccount(aIndex)
    SQLQuery(string.format("SELECT HasPass FROM BattlePass_Accounts WHERE AccountID = '%s'", account))
    local hasPass = (SQLFetch() ~= 100 and SQLGetNumber("HasPass") == 1)
    SQLClose()
    return hasPass
end

-- [[ LISTAGEM DE MISS�ES (LIMPA PARA CHAT GLOBAL) ]]
function BattlePass.ListMissions(aIndex)
    local account = GetObjectAccount(aIndex)
    local time = BattlePass.GetCurrentTime()
    
    SQLQuery(string.format("SELECT MissionID, Progress, IsFinished FROM BattlePass_Progress WHERE AccountID='%s'", account))
    local progressTable = {}
    while SQLFetch() ~= 100 do
        progressTable[SQLGetNumber("MissionID")] = { 
            cur = SQLGetNumber("Progress"), 
            fin = SQLGetNumber("IsFinished") 
        }
    end
    SQLClose()

    local function ShowList(list, label)
        if not list then return end
        for _, m in ipairs(list) do
            local p = progressTable[m.ID] or { cur = 0, fin = 0 }
            local status = p.fin == 1 and "[CONCLUIDA]" or string.format("%d/%d", p.cur, m.Count)
            local premiumTag = m.ReqPremium and "[P] " or ""
            -- Envia apenas a linha da miss�o diretamente
            NoticeSend(aIndex, 1, string.format("[%s] %s%s: %s (%d Estrelas)", label, premiumTag, m.Name, status, m.Stars))
        end
    end

    ShowList(CONFIG.DailyMissions[time.Day], "DIARIA")
    ShowList(CONFIG.WeeklyMissions[time.Week], "SEMANAL")
end

-- [[ COMANDO DE INFORMA��ES ]]
function BattlePass.ShowInfo(aIndex)
    local stars, level = BattlePass.GetPlayerStats(aIndex)
    local pointsNextLevel = 50 - (stars % 50)
    
    if stars % 50 == 0 and stars > 0 then pointsNextLevel = 0 end 

    NoticeSend(aIndex, 0, string.format("[BP] Seu Status: Nivel %d | Total de Estrelas: %d", level, stars))
    if pointsNextLevel > 0 then
        NoticeSend(aIndex, 1, string.format("[BP] Faltam %d estrelas para o Nivel %d!", pointsNextLevel, level + 1))
    else
        NoticeSend(aIndex, 1, "[BP] Voce atingiu o limite de estrelas atual. Suba de nivel!")
    end
end

-- [[ COMPRA DO PASSE ]]
function BattlePass.Purchase(aIndex)
    if BattlePass.IsExpired() then return end
    if BattlePass.HasPass(aIndex) then
        NoticeSend(aIndex, 1, "[BattlePass] Voce ja possui o Passe Premium!")
        return
    end

    local account = GetObjectAccount(aIndex)
    local coins = ObjectGetCoin(aIndex)
    
    if (coins.Coin1 or 0) >= CONFIG.PriceWCoinC then
        ObjectSubCoin(aIndex, CONFIG.PriceWCoinC, 0, 0)
        
        SQLQuery(string.format("SELECT HasPass FROM BattlePass_Accounts WHERE AccountID = '%s'", account))
        if SQLFetch() ~= 100 then
            SQLClose()
            SQLQuery(string.format("UPDATE BattlePass_Accounts SET HasPass = 1 WHERE AccountID = '%s'", account))
        else
            SQLClose()
            SQLQuery(string.format("INSERT INTO BattlePass_Accounts (AccountID, HasPass) VALUES ('%s', 1)", account))
        end
        SQLClose()

        BattlePass.SyncClient(aIndex)
        NoticeSend(aIndex, 0, "[BattlePass] Passe Premium ativado com sucesso!")
        BP_Log(1, "Account " .. account .. " comprou o Passe Premium.")
    else
        NoticeSend(aIndex, 1, string.format("[BattlePass] WCoins insuficientes. Necessario: %d", CONFIG.PriceWCoinC))
    end
end

-- [[ C�LCULO DE PROGRESSO ]]
function BattlePass.GetPlayerStats(aIndex)
    local account = GetObjectAccount(aIndex)
    local totalStars = 0
    
    SQLQuery(string.format("SELECT MissionID FROM BattlePass_Progress WHERE AccountID='%s' AND IsFinished=1", account))
    local finishedMissions = {}
    while SQLFetch() ~= 100 do
        finishedMissions[SQLGetNumber("MissionID")] = true
    end
    SQLClose()

    for _, missions in pairs(CONFIG.DailyMissions) do
        for _, m in ipairs(missions) do
            if finishedMissions[m.ID] then totalStars = totalStars + m.Stars end
        end
    end

    for _, missions in pairs(CONFIG.WeeklyMissions) do
        for _, m in ipairs(missions) do
            if finishedMissions[m.ID] then totalStars = totalStars + m.Stars end
        end
    end

    return totalStars, math.floor(totalStars / 50)
end

-- Envia as miss�es para preencher a aba "MISSOES" na interface
function BattlePass.SendMissions(aIndex)
    local account = GetObjectAccount(aIndex)
    local time = BattlePass.GetCurrentTime()
    
    -- Busca progresso no SQL para sincronizar com a UI
    SQLQuery(string.format("SELECT MissionID, Progress, IsFinished FROM BattlePass_Progress WHERE AccountID='%s'", account))
    local progressTable = {}
    while SQLFetch() ~= 100 do
        progressTable[SQLGetNumber("MissionID")] = { cur = SQLGetNumber("Progress"), fin = SQLGetNumber("IsFinished") }
    end
    SQLClose()

    local function PacketMission(list, group)
        if not list then return end
        for _, m in ipairs(list) do
            local p = progressTable[m.ID] or { cur = 0, fin = 0 }
            ClearPacket("BP_MISSION")
            SetBytePacket("BP_MISSION", group)
            SetWordPacket("BP_MISSION", m.ID)
            SetBytePacket("BP_MISSION", m.Type)
            SetWordPacket("BP_MISSION", m.TargetID)
            SetWordPacket("BP_MISSION", m.Count)
            SetWordPacket("BP_MISSION", p.cur)
            SetWordPacket("BP_MISSION", m.Stars)
            SetBytePacket("BP_MISSION", m.ReqPremium and 1 or 0)
            SetBytePacket("BP_MISSION", p.fin)
            SetCharPacketLength("BP_MISSION", m.Name, 40)
            SendPacket("BP_MISSION", aIndex)
        end
    end

    PacketMission(CONFIG.DailyMissions[time.Day], 1)
    PacketMission(CONFIG.WeeklyMissions[time.Week], 2)
end

-- Fun��o principal de sincroniza��o (Substitui a existente na linha 125)
function BattlePass.SyncClient(aIndex)
    local stars, level = BattlePass.GetPlayerStats(aIndex)
    local hasPass = BattlePass.HasPass(aIndex) and 1 or 0
    local time = BattlePass.GetCurrentTime()
    
    ClearPacket("BP_DATA")
    SetWordPacket("BP_DATA", level)
    SetWordPacket("BP_DATA", stars)
    SetWordPacket("BP_DATA", stars % 50) -- XP atual dentro do n�vel
    SetWordPacket("BP_DATA", 50)         -- XP total para o pr�ximo n�vel
    SetBytePacket("BP_DATA", hasPass)
    SetWordPacket("BP_DATA", CONFIG.PriceWCoinC)
    SetBytePacket("BP_DATA", time.Day)
    SetBytePacket("BP_DATA", time.Week)
    SetBytePacket("BP_DATA", 0)          -- Status de expira��o (0 = Ativo)
    SendPacket("BP_DATA", aIndex)

    -- Chama os envios detalhados
    BattlePass.SendMissions(aIndex)
    BattlePass.SendRewards(aIndex) -- Esta fun��o j� existe na sua linha 214
end

-- [[ ATUALIZA��O DE PROGRESSO ]]
function BattlePass.UpdateProgress(aIndex, actionType, targetID)
    if not aIndex or BattlePass.IsExpired() then return end

    local time = BattlePass.GetCurrentTime()
    local hasPremium = BattlePass.HasPass(aIndex)

    local dailyList = CONFIG.DailyMissions[time.Day]
    if dailyList then
        for _, mission in ipairs(dailyList) do
            if mission.Type == actionType and (mission.TargetID == -1 or mission.TargetID == targetID) then
                if not mission.ReqPremium or (mission.ReqPremium and hasPremium) then
                    BattlePass.SavePoint(aIndex, mission, string.format("Dia %d", time.Day))
                end
            end
        end
    end

    local weeklyList = CONFIG.WeeklyMissions[time.Week]
    if weeklyList then
        for _, mission in ipairs(weeklyList) do
            if mission.Type == actionType and (mission.TargetID == -1 or mission.TargetID == targetID) then
                if not mission.ReqPremium or (mission.ReqPremium and hasPremium) then
                    BattlePass.SavePoint(aIndex, mission, string.format("Semana %d", time.Week))
                end
            end
        end
    end
end

-- [[ SALVAMENTO SEGURO NO SQL COM FEEDBACK VISUAL ]]
function BattlePass.SavePoint(aIndex, mission, contextStr)
    local account = GetObjectAccount(aIndex)
    
    SQLQuery(string.format("SELECT Progress, IsFinished FROM BattlePass_Progress WHERE AccountID='%s' AND MissionID=%d", account, mission.ID))
    local res = SQLFetch()
    local cur, fin = 0, 0
    
    if res ~= 100 then
        cur = SQLGetNumber("Progress")
        fin = SQLGetNumber("IsFinished")
        SQLClose()
    else
        SQLClose()
        cur = 1
        local isFin = (cur >= mission.Count) and 1 or 0
        SQLQuery(string.format("INSERT INTO BattlePass_Progress (AccountID, MissionID, Progress, IsFinished) VALUES ('%s', %d, %d, %d)", account, mission.ID, cur, isFin))
        SQLClose()
        
        NoticeSend(aIndex, 1, string.format("[BP | %s] %s: %d/%d", contextStr, mission.Name, cur, mission.Count))
        
        if isFin == 1 then
            local stars, lvl = BattlePass.GetPlayerStats(aIndex)
            NoticeSend(aIndex, 0, string.format("[BP | %s] Missao Concluida: %s!", contextStr, mission.Name))
            NoticeSend(aIndex, 0, string.format("[BP] +%d Estrelas! Saldo Atual: %d", mission.Stars, stars))
        end
        BattlePass.SyncClient(aIndex)
        return
    end

    if fin == 1 then return end

    cur = cur + 1
    NoticeSend(aIndex, 1, string.format("[BP | %s] %s: %d/%d", contextStr, mission.Name, cur, mission.Count))

    if cur >= mission.Count then
        SQLQuery(string.format("UPDATE BattlePass_Progress SET Progress=%d, IsFinished=1 WHERE AccountID='%s' AND MissionID=%d", cur, account, mission.ID))
        SQLClose()
        
        local stars, lvl = BattlePass.GetPlayerStats(aIndex)
        NoticeSend(aIndex, 0, string.format("[BP | %s] Missao Concluida: %s!", contextStr, mission.Name))
        NoticeSend(aIndex, 0, string.format("[BP] +%d Estrelas! Saldo Atual: %d", mission.Stars, stars))
    else
        SQLQuery(string.format("UPDATE BattlePass_Progress SET Progress=%d WHERE AccountID='%s' AND MissionID=%d", cur, account, mission.ID))
        SQLClose()
    end
    
    BattlePass.SyncClient(aIndex)
end

-- [[ RESGATE DE RECOMPENSAS ]]
function BattlePass.ClaimReward(aIndex, level)
    local stars, currentLevel = BattlePass.GetPlayerStats(aIndex)
    
    if level > currentLevel then
        NoticeSend(aIndex, 1, "[BattlePass] Nivel insuficiente para este resgate!")
        return 
    end

    local reward = CONFIG.Rewards[level]
    if not reward then return end

    local account = GetObjectAccount(aIndex)
    local hasPremium = BattlePass.HasPass(aIndex)

    local function ExecuteClaim(rewardList, typeName)
        SQLQuery(string.format("SELECT Level FROM BattlePass_Claimed WHERE AccountID='%s' AND Level=%d AND RewardType='%s'", account, level, typeName))
        if SQLFetch() == 100 then
            SQLClose()
            
            for _, rewardData in ipairs(rewardList) do
                if rewardData.Type == "ITEM" then
                    local d = rewardData.Data
                    local s = d.Sockets
                    local amount = rewardData.Count or 1
                    for i = 1, amount do
                        ItemGiveEx(aIndex, GET_ITEM(d.Section, d.Index), d.Level, 0, d.Skill, d.Luck, d.Option, d.Exc, d.Anc, 0, 0, s[1], s[2], s[3], s[4], s[5], 0, d.Duration)
                    end
                elseif rewardData.Type == "WCOIN" then 
                    ObjectAddCoin(aIndex, rewardData.Value, 0, 0) 
                end
            end
            
            SQLQuery(string.format("INSERT INTO BattlePass_Claimed (AccountID, Level, RewardType, Date) VALUES ('%s', %d, '%s', GETDATE())", account, level, typeName))
            SQLClose()
            return true
        else
            SQLClose()
            return false
        end
    end

    local resgatouFree = ExecuteClaim(reward.Free, "FREE")
    local resgatouPremium = false
    if hasPremium then resgatouPremium = ExecuteClaim(reward.Premium, "PREMIUM") end
    
    if resgatouFree and resgatouPremium then
        NoticeSend(aIndex, 0, string.format("[BP] Recompensas Free e Premium (Nivel %d) resgatadas!", level))
    elseif resgatouFree then
        NoticeSend(aIndex, 0, string.format("[BP] Recompensa Free (Nivel %d) resgatada!", level))
    elseif resgatouPremium then
        NoticeSend(aIndex, 0, string.format("[BP] Recompensa Premium (Nivel %d) resgatada!", level))
    else
        NoticeSend(aIndex, 1, string.format("[BP] Voce ja resgatou todas as recompensas do nivel %d.", level))
    end
end

-- [[ GATILHOS ]]
function BP_OnCommand(aIndex, Arg)
    local msg = string.lower(tostring(Arg))
    
    if msg == "/comprarpasse" then BattlePass.Purchase(aIndex); return 1 end
    if msg == "/infobp" then BattlePass.ShowInfo(aIndex); return 1 end
    if msg == "/missoes" then BattlePass.ListMissions(aIndex); return 1 end

    if string.find(msg, "/resgatar") then
        local lvl = tonumber(string.match(msg, "/resgatar (%d+)"))
        if lvl then BattlePass.ClaimReward(aIndex, lvl) end
        return 1
    end
    return 0
end

function BP_OnMonsterDie(MonsterIndex, KillerIndex)
    if not KillerIndex or KillerIndex < 0 then return end
    BattlePass.UpdateProgress(KillerIndex, 1, GetObjectClass(MonsterIndex))
end

function BP_OnUserDie(VictimIndex, KillerIndex)
    if not KillerIndex or KillerIndex < 0 then return end
    BattlePass.UpdateProgress(KillerIndex, 2, GetObjectClass(VictimIndex))
end

function BP_OnCharacterEntry(aIndex) BattlePass.SyncClient(aIndex) end
function BP_OnUserLevelUp(aIndex, level) return -1 end

BridgeFunctionAttach('OnMonsterDie', 'BP_OnMonsterDie')
BridgeFunctionAttach('OnUserDie', 'BP_OnUserDie')
BridgeFunctionAttach('OnCommandManager', 'BP_OnCommand')
BridgeFunctionAttach('OnCharacterEntry', 'BP_OnCharacterEntry')
BridgeFunctionAttach('OnUserLevelUp', 'BP_OnUserLevelUp')

return BattlePass